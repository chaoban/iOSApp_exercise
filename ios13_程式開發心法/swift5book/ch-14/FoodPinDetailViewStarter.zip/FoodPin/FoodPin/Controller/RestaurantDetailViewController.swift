//
//  RestaurantDetailViewController.swift
//  FoodPin
//
//  Created by Simon Ng on 28/10/2019.
//  Copyright © 2019 AppCoda. All rights reserved.
//

import UIKit

class RestaurantDetailViewController: UIViewController {

    
    var restaurant = Restaurant()
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

}
