//
//  ViewController.swift
//  StackViewDemo
//
//  Created by Simon Ng on 27/10/2019.
//  Copyright © 2019 AppCoda. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

